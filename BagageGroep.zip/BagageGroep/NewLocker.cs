using System;

namespace BagageGroep;

public partial class Program
{
    public static int NewLocker()
    {
        //logica om nieuwe kluis te openen
        return 0;
    }
}
