﻿namespace BagageGroep;

partial class Program
{
    public const int TotalLockers = 100;
    public const string LockerFile = "lockers.txt";
    static void Main(string[] args)
    {
        Console.WriteLine("Welkom bij zwembad de golf!\n");
        //stop hier je hoofd loop

        //laat het menu zien
        // Console.WriteLine("1. Laat het aantal kluizen zien.");
        //etc.

    }
}
