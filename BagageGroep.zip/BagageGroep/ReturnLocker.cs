using System;

namespace BagageGroep;

public partial class Program
{
    public static bool ReturnLocker()
    {
        //logica om  kluis permanent te openen
        return false;
    }
}
