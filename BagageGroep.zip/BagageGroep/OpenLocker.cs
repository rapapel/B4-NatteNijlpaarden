using System;

namespace BagageGroep;

public partial class Program
{
    public static bool OpenLocker()
    {
        //logica om  kluis te openen
        return false;
    }
}
