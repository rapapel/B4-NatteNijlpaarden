using System;

namespace BagageGroep;

public partial class Program
{
    //helper functie template voor het uitlezen van het bestand
    public static List<Kluis> GetLockersFromFile()
    {
        return [];
    }
    //helper functie template voor het schrijven van het bestand
    public static void SaveLockersToFile(List<Kluis> lockers)
    {
        //logica om lockers te schrijven naar bestand
    }
}
