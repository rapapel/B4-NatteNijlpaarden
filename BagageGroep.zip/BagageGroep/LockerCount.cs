using System;

namespace BagageGroep;

public class LockerCount
{ 
    public int Count { get; set; }
        int count = 0;
        //vind aantal
        return count;
 
}